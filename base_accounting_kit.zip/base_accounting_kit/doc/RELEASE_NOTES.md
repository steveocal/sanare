## Module <base_accounting_kit>

#### 17.09.2025
#### Version 19.0.1.0.0
#### ADD
- Initial commit for Odoo 19 Full Accounting Kit for Community

#### 21.10.2025
#### Version 19.0.2.0.0
#### ADD
- Added Customer Statement feature.

#### 09.01.2026
#### Version 19.0.2.1.0
#### ADD
- Fixed the issue in the bank statement import.

#### 09.02.2026
#### Version 19.0.2.2.0
#### UPDT
- Fixed the issues in the bank statement import of csv and ofx files.
- 
#### 25.03.2026
#### Version 19.0.2.3.0
#### UPDT
- Fixed the issue in fiscal year dates.


#### 08.07.2026
#### Version 19.0.3.3.0
#### IMP
- Fixed Coding Issues and detailed code rafactoring
- New Features Added
