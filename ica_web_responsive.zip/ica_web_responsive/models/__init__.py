# Part of Odoo. See LICENSE file for full copyright and licensing details.

from . import ir_http, res_users_settings
