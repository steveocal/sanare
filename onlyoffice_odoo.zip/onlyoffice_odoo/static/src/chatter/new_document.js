/** @odoo-module **/
// Copyright (C) 2026 Ascensio System SIA

import { Chatter } from "@mail/chatter/web_portal/chatter"

import { _t } from "@web/core/l10n/translation"
import { Dropdown } from "@web/core/dropdown/dropdown"
import { DropdownItem } from "@web/core/dropdown/dropdown_item"
import { patch } from "@web/core/utils/patch"
import { useDropdownState } from "@web/core/dropdown/dropdown_hooks"
import { useService } from "@web/core/utils/hooks"

Object.assign(Chatter.components, { Dropdown, DropdownItem })

const NEW_DOCUMENT_FORMATS = [
  { ext: "docx", label: _t("Word Document (.docx)") },
  { ext: "xlsx", label: _t("Spreadsheet (.xlsx)") },
  { ext: "pptx", label: _t("Presentation (.pptx)") },
]

patch(Chatter.prototype, {
  setup() {
    super.setup(...arguments)
    this.onlyofficeOrm = useService("orm")
    this.onlyofficeActionService = useService("action")
    this.onlyofficeNotification = useService("notification")
    this.onlyofficeNewDocumentDropdown = useDropdownState()
    this.onlyofficeNewDocumentFormats = NEW_DOCUMENT_FORMATS
  },

  async onlyofficeCreateDocument(ext) {
    if (!this.props.threadId) {
      this.onlyofficeNotification.add(_t("Save the record before creating a document."), {
        type: "warning",
      })
      return
    }

    let attachmentId
    try {
      attachmentId = await this.onlyofficeOrm.call("onlyoffice.odoo", "create_blank_document", [
        this.props.threadModel,
        this.props.threadId,
        ext,
      ])
    } catch {
      this.onlyofficeNotification.add(_t("Could not create the document."), { type: "danger" })
      return
    }

    await this.load(this.state.thread, ["attachments"])
    this.state.isAttachmentBoxOpened = true

    const { same_tab } = JSON.parse(await this.onlyofficeOrm.call("onlyoffice.odoo", "get_same_tab"))
    if (same_tab) {
      this.onlyofficeActionService.doAction({
        params: { attachment_id: attachmentId },
        tag: "onlyoffice_editor",
        target: "current",
        type: "ir.actions.client",
      })
      return
    }
    window.open(`/onlyoffice/editor/${attachmentId}`, "_blank")
  },
})
