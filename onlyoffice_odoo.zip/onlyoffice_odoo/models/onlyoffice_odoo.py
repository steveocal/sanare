# Copyright (C) 2026 Ascensio System SIA

import json

from odoo import _, api, models
from odoo.exceptions import UserError
from odoo.tools.translate import LazyTranslate

from odoo.addons.onlyoffice_odoo.utils import config_constants, file_utils

_lt = LazyTranslate(__name__)

NEW_DOCUMENT_TITLES = {
    "docx": _lt("New Document"),
    "xlsx": _lt("New Spreadsheet"),
    "pptx": _lt("New Presentation"),
}


class OnlyOfficeTemplate(models.Model):
    _name = "onlyoffice.odoo"
    _description = "ONLYOFFICE"

    @api.model
    def get_demo(self):
        mode = self.env["ir.config_parameter"].sudo().get_param(config_constants.DOC_SERVER_DEMO)
        date = self.env["ir.config_parameter"].sudo().get_param(config_constants.DOC_SERVER_DEMO_DATE)
        return json.dumps({"mode": mode, "date": date})

    @api.model
    def get_same_tab(self):
        same_tab = self.env["ir.config_parameter"].sudo().get_param(config_constants.SAME_TAB)
        return json.dumps({"same_tab": same_tab})

    @api.model
    def create_blank_document(self, res_model, res_id, ext):
        """Attach a blank docx/xlsx/pptx to ``res_model``/``res_id`` and return its attachment id."""
        if ext not in ("docx", "xlsx", "pptx"):
            raise UserError(_("Unsupported document type: %(ext)s", ext=ext))

        record = self.env[res_model].browse(int(res_id))
        record.check_access("write")

        lang = self.env.user.lang or "en_US"
        content = file_utils.get_default_file_template(lang, ext)

        title = NEW_DOCUMENT_TITLES[ext]
        existing = self.env["ir.attachment"].search_count(
            [
                ("res_model", "=", res_model),
                ("res_id", "=", int(res_id)),
                ("name", "=like", f"{title}%.{ext}"),
            ]
        )
        name = f"{title}.{ext}" if not existing else f"{title} ({existing + 1}).{ext}"

        attachment = self.env["ir.attachment"].create(
            {
                "name": name,
                "res_model": res_model,
                "res_id": int(res_id),
                "type": "binary",
                "mimetype": file_utils.get_mime_by_ext(ext),
                "raw": content,
            }
        )
        return attachment.id
